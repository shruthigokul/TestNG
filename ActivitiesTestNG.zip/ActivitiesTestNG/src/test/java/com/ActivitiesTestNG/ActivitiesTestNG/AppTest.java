package com.ActivitiesTestNG.ActivitiesTestNG;





/**
 * Unit test for simple App.
 */
public class AppTest 
{
    /**
     * Rigorous Test :-)
     */
 
}
