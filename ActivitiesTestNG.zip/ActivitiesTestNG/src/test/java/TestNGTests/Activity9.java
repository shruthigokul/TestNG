package TestNGTests;

import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Activity9 {
	
public WebDriver driver=null;
	
	

	@BeforeClass()
	public void init()
	{
		{
			Reporter.log("Opening the firefox browser",true);
			System.setProperty("webdriver.gecko.driver","C:\\Users\\ShruthiGokul\\Downloads\\geckodriver-v0.27.0-win64\\geckodriver.exe");
			driver=new FirefoxDriver();
			Reporter.log("Maximising browser window",true);
			driver.get("https://www.training-support.net/selenium/javascript-alerts");
			driver.manage().timeouts().implicitlyWait(10 ,TimeUnit.SECONDS); 
			
		}
	}
	
	@BeforeMethod()
	public void BeforeMethod()
	{
		Reporter.log("Switching to default page",true);
		driver.switchTo().defaultContent();
	}

	@Test(priority=0)
	public void simpleAlertTestCase() throws InterruptedException
	{
		//clicking on the button for simple alert
		Reporter.log("Clicking on button for simple alert",true);
		driver.findElement(By.xpath("//button[@id='simple']")).click();
		
		//switching to alert and getting text
		Reporter.log("Getting the text from simple alert",true);
		String simpleAlertText=driver.switchTo().alert().getText();
		
		//printing text from alert
		Reporter.log("The string in simple alert is :"+simpleAlertText,true);
		//System.out.println(simpleAlertText);
		
		//clicking on ok button
		Reporter.log("Clicking ok button in alert",true);
		driver.switchTo().alert().accept();
		
		//end of simple test
		Reporter.log("Simple alert test ending..",true);
		
		
	}
	
	@Test(priority=1)
	public void confirmAlertTestCase() throws InterruptedException
	{
		
		//clicking on the button for confirm alert
				Reporter.log("Clicking on button for confirm alert",true);
				driver.findElement(By.xpath("//button[@id='confirm']")).click();
				
				//switching to alert and getting text
				Reporter.log("Getting the text from confirm alert",true);
				String confirmAlertText=driver.switchTo().alert().getText();
				
				//printing text from alert
				Reporter.log("The string in confirm alert is :"+confirmAlertText,true);
				//System.out.println(confirmAlertText);
				
				//clicking on ok button
				Reporter.log("Clicking ok button in alert",true);
				driver.switchTo().alert().accept();
				
				//end of confirm test
				Reporter.log("confirm alert test ending..",true);
			
	}
	
	@Test(priority=2)
	public void promptAlertTestCase() throws InterruptedException
	{
		//clicking on the button for prompt alert
		Reporter.log("Clicking on button for prompt alert",true);
		driver.findElement(By.xpath("//button[@id='prompt']")).click();
		
		//switching to alert and getting text
		Reporter.log("Getting the text from prompt alert",true);
		String promptAlertText=driver.switchTo().alert().getText();
		
		//printing text from alert
		Reporter.log("The string in prompt alert is :"+promptAlertText,true);
		//System.out.println(promptAlertText);
		
		//clicking on ok button
		Reporter.log("Entering text",true);
		driver.switchTo().alert().sendKeys("text1");;
		
		//clicking on ok button
		Reporter.log("Clicking ok button in alert",true);
		driver.switchTo().alert().accept();
		
		//end of prompt test
		Reporter.log("prompt alert test ending..",true);
		
	}
	

	@AfterClass()
	public void aftertesting()
	{
		driver.quit();
	}
	
	
}
