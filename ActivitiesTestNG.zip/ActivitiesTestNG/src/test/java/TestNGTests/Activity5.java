package TestNGTests;

import static org.testng.Assert.assertTrue;

import java.security.PublicKey;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.server.handler.GetTitle;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Activity5 {

	WebDriver driver=null;
	
	@BeforeMethod()
	public void init()
	{
		{
			System.setProperty("webdriver.gecko.driver","C:\\Users\\ShruthiGokul\\Downloads\\geckodriver-v0.27.0-win64\\geckodriver.exe");
			driver=new FirefoxDriver();
			driver.get("https://www.training-support.net/selenium/target-practice");
			driver.manage().timeouts().implicitlyWait(10 ,TimeUnit.SECONDS); 
		}
	}

	@Test(groups={"HeaderTests","ButtonTests"})
	public void GetTitle()
	{
		//asserting the title
		assertTrue(driver.getTitle().equals("Target Practice"),"The title is as expected");
		
	}
	
	@Test(dependsOnMethods= {"GetTitle"},groups= {"HeaderTests"})
	public void checkHeader1() throws InterruptedException
	{
		//Checking the header text in third header
		String thirdHeader=driver.findElement(By.xpath("//div/h3")).getAttribute("innerText");
		assertTrue(thirdHeader.equals("Third header"),"The title is as expected");
		
	}
	
	@Test(dependsOnMethods= {"GetTitle"},groups= {"HeaderTests"})
	public void checkHeader2() throws InterruptedException
	{
		//Asserting the colour of fifth header.
		assertTrue(driver.findElement(By.xpath("//div/h5")).getCssValue("color").equals("rgb(33, 186, 69)"),"The color is as exdpected");
		
	}
	

	@Test(dependsOnMethods= {"GetTitle"},groups= {"ButtonTests"})
	public void checkButton1() throws InterruptedException
	{
		//finding element that contains olive in class
		assertTrue(driver.findElement(By.xpath("//button[contains(@class,'olive')]")).getAttribute("innerText").equals("Olive"),"The text is as expected");	
	}
	
	@Test(dependsOnMethods= {"GetTitle"},groups= {"ButtonTests"})
	public void checkButton2() throws InterruptedException
	{
		//finding the color of first button in third row
		String colorr=driver.findElement(By.xpath("//div[@class='column']/div[3]/button")).getCssValue("color");
		assertTrue(colorr.equals("rgb(255, 255, 255)"),"the color is as expected");	
	}
	
	@AfterMethod()
	public void aftermeth()
	{
		driver.quit();
	}
	
}
