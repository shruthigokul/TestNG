package TestNGTests;

import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;
import static org.testng.Assert.fail;

import java.util.concurrent.TimeUnit;

import javax.swing.text.Document;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Activity2test {
	
	public WebDriver driver=null;
	
	@BeforeMethod()
	public void init()
	{
		{
			System.setProperty("webdriver.gecko.driver","C:\\Users\\ShruthiGokul\\Downloads\\geckodriver-v0.27.0-win64\\geckodriver.exe");
			driver=new FirefoxDriver();
			driver.get("https://www.training-support.net/selenium/target-practice");
			driver.manage().timeouts().implicitlyWait(10 ,TimeUnit.SECONDS);
		}
	}

	@Test(priority=0)
	public void firsttest() throws InterruptedException
	{
		
		Thread.sleep(5000);
		String title=driver.getTitle();
		System.out.println(title);
		
	}
	
	@Test(priority=1)
	public void secondtest()
	{
		
		driver.findElement(By.xpath("//button[@class='ui black button']")).click();
		assertTrue(false,"the black button is not seen");
		
	}
	
	@Test(priority=2,enabled=false)
	public void thirdtest()
	{
		
		
		
	}
	
	@Test(priority=3)
	public void fourthtest() throws SkipException
	{
		
		throw new SkipException("skipping test#4");
		
	}
	

	@AfterMethod()
	public void aftermeth()
	{
		driver.quit();
	}

}
