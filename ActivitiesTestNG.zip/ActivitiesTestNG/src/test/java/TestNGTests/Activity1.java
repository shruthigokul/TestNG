package TestNGTests;

import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Activity1 {

public WebDriver driver=null;
	
	@BeforeMethod()
	public void init()
	{
		{
			System.setProperty("webdriver.gecko.driver","C:\\Users\\ShruthiGokul\\Downloads\\geckodriver-v0.27.0-win64\\geckodriver.exe");
			driver=new FirefoxDriver();
			driver.get("https://www.training-support.net");
			driver.manage().timeouts().implicitlyWait(10 ,TimeUnit.SECONDS); 
		}
	}

	@Test(priority=0)
	public void firsttest() throws InterruptedException
	{
		
		String title=driver.getTitle();
		System.out.println(title);
		assertTrue(title.equals("Training Support"),"The title matches with the expected");
		
		driver.findElement(By.xpath("//a[@id='about-link']")).click();
		String newTitleString=driver.getTitle();
		System.out.println(newTitleString);
		assertTrue(title.equals("About Training Support"),"The title matches with the expected");
	}
	

	@AfterMethod()
	public void aftermeth()
	{
		driver.quit();
	}

}
