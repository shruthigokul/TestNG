package TestNGTests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import okhttp3.Credentials;

public class Activity7 {

	WebDriver driver=null;
	
	@BeforeMethod()
	public void init()
	{
		{
			System.setProperty("webdriver.gecko.driver","C:\\Users\\ShruthiGokul\\Downloads\\geckodriver-v0.27.0-win64\\geckodriver.exe");
			driver=new FirefoxDriver();
			driver.get("https://www.training-support.net/selenium/login-form");
			driver.manage().timeouts().implicitlyWait(10 ,TimeUnit.SECONDS); 
		}
	}

	@Test(dataProvider="Authentication")
	public void firsttest(String Username,String Password) throws InterruptedException
	{
		driver.findElement(By.xpath("//input[@id='username']")).sendKeys(Username);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys(Password);
		driver.findElement(By.xpath("//button[@class='ui button']")).click();
		
		 //Assert Message
        String loginMessage = driver.findElement(By.id("action-confirmation")).getText();
        Assert.assertEquals(loginMessage, "Welcome Back, admin");
	}
	
	@DataProvider(name="Authentication")
	public static Object[][] Credentials()
	{
		return new Object[][] {{"admin","password"}};
	}
	

	@AfterMethod()
	public void aftermeth()
	{
		driver.quit();
	}
}
