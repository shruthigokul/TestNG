package TestNGTests;

import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Activity3 {
	
public WebDriver driver=null;
	
		@BeforeMethod()
		public void init()
		{
			{
				System.setProperty("webdriver.gecko.driver","C:\\Users\\ShruthiGokul\\Downloads\\geckodriver-v0.27.0-win64\\geckodriver.exe");
				driver=new FirefoxDriver();
				driver.get(" https://www.training-support.net/selenium/login-form");
				driver.manage().timeouts().implicitlyWait(10 ,TimeUnit.SECONDS); 
			}
		}
	
		@Test(priority=0)
		public void firsttest() throws InterruptedException
		{
			
			//finding username,password and login button field
			driver.findElement(By.xpath("//input[@id='username']")).sendKeys("admin");
			driver.findElement(By.xpath("//input[@id='password']")).sendKeys("password");
			driver.findElement(By.xpath("//button[@class='ui button']")).click();
			
			//to get the login confirmation message
			String confirmationMessage=driver.findElement(By.xpath("//div[@id='action-confirmation']")).getAttribute("innerText");
			
			//Assert the confirmation message
			assertTrue(confirmationMessage.trim().equals("Welcome Back, admin"),"The confirmation message matches with the expected");
			
			}
		
	
		@AfterMethod()
		public void aftermeth()
		{
			driver.quit();
		}
		
}
